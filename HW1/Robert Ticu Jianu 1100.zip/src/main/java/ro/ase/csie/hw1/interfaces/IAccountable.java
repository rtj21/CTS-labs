package ro.ase.csie.hw1.interfaces;

import ro.ase.csie.hw1.models.Account;

public interface IAccountable {
    public abstract double getMonthlyRate(Account account);
}
