package ro.ase.csie.hw1.Exceptions;

public class InvalidLoanValueException extends RuntimeException{
}
