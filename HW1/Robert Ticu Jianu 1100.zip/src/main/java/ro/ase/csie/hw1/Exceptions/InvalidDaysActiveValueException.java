package ro.ase.csie.hw1.Exceptions;

public class InvalidDaysActiveValueException extends RuntimeException{
}
