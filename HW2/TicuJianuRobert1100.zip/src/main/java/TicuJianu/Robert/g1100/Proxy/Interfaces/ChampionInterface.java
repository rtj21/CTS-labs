package TicuJianu.Robert.g1100.Proxy.Interfaces;

public interface ChampionInterface {
    public void attack();
    public void defend();
    public void hurt(int dmg);
}
