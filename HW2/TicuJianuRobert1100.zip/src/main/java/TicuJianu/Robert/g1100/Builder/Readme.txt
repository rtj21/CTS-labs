The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

The champion class has a lot of attributes, some of which are critical and others which are not used all the time and due
to the complexity of the object, sometimes I forget to initialize the variables.

Advantages:
	makes sure that an object will contain the critical part of attributes
	allows for later adding of attributes
	adds flexibility to creating objects

Disadvantages:
	attributes can be omitting when creating the object
	makes for lengthy lines of codes when you cascade the add methods