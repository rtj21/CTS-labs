The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

All players need the same champion and the generation process for a champion and its pet is very resource-hungry, even though the models are exactly the same

Advantages:
	time efficient (the model is only generated once)
	allows the programmer to avoid the constructor

Disadvantages:
	memory inefficient
	add the risk of shallow copy
