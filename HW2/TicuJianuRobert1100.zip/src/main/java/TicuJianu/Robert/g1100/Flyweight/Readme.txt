The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

All the skins have the same 3D model behind, but the player can choose its primary and secondary color according to their liking

Advantages:
	very memory efficient
	time efficient (it doesnt generate a new big object, just takes an already existing one)

Disadvantages:
	must have a temporary state that can be stored externally
	inefficient if there are too many unique kinds of objects
