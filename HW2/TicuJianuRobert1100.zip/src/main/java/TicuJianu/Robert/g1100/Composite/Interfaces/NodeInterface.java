package TicuJianu.Robert.g1100.Composite.Interfaces;

public interface NodeInterface {
    public String getName();
    public int getCost();
}
