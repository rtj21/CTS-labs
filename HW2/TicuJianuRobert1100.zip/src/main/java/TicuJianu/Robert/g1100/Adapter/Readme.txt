The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

I want to implement a condition for which a champion can't defend if he is too hurt and he dies.

Advantages:
    being able to mitigate the access to an object based on a chosen condition
