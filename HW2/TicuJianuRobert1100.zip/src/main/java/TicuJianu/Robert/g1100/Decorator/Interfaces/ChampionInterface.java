package TicuJianu.Robert.g1100.Decorator.Interfaces;

public interface ChampionInterface {
    public void attack();
    public void defend(int dmg);
}
