The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

A champion will start with the most basic abilities and items and during the game when he progresses he will be able
to use new and better weapons/abilities

Advantages:
	allows for extending the functionality of an object at run time
	allows for adding multiple functionalities

Disadvantages
	depending on the implementation, it can be cumbersome to access the right attribute
	if used too many times, many objects will be generated with different behaviour which will make debugging harder
