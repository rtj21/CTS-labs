The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

My web app creates multiple types of characters for a video game and the factory would ease the creation phase of these characters.

Advantages:
    easy to create characters
    the app will still compile if I modify a character type

Disadvantages:
    requires a big number of classes to be efficient
    classes the factory builds need to be related in one way or another