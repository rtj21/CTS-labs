package TicuJianu.Robert.g1100.Adapter.Interfaces;

public interface DefensiveInterface {
    public void defend();
    public void guarding(int hit);
}
