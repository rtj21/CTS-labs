package TicuJianu.Robert.g1100.Factory.Models;

public enum ChampionType {
    Support, Marksman, Bruiser
}
