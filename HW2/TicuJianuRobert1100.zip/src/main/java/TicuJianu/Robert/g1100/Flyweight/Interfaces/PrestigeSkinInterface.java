package TicuJianu.Robert.g1100.Flyweight.Interfaces;

import TicuJianu.Robert.g1100.Flyweight.Models.SkinContext;

public interface PrestigeSkinInterface {
    public void applySkin(SkinContext context);
}
