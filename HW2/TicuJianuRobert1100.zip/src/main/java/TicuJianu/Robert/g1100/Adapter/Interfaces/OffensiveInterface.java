package TicuJianu.Robert.g1100.Adapter.Interfaces;

public interface OffensiveInterface {
    public void attack();
    public void train(int hit);
}
