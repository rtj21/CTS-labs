The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

My application has a Security Testing phase which uses Snyk for that and for the free version you are only allowed to have
one component checked at a time per account, anything extra would require a paid plan.

Advantages:
    -making sure that there can only be one connection
    -avoiding extra costs for the paid plan

Disadvantages:
    -not being able to have more connections if needed for multitasking
    -basically making the class a blackbox which will not be appreciated by the QA team :D