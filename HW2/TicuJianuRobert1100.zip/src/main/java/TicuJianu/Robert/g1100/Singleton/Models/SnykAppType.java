package TicuJianu.Robert.g1100.Singleton.Models;

public enum SnykAppType {
    Java, Kotlin, DockerImage, C, Cpp, Cs, Jenkinsfile
}
