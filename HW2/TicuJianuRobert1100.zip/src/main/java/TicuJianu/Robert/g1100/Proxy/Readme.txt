The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

I want to limit the behaviour of a champions to be able to defend to only if he is healthy enough to do so.

Advantages:
    restricting the access to an object depending on the condition that we choose
    not having to rewrite the code if we want to add this security check

Disadvantages:
    if its object that it wraps is faulty proxy will also fail and mask the problem/reason why it fails to the programmer
