The title for my Bachelor Thesis is DevOps Solution for automation testing, which is not exactly primarily focused on the programming,
but I do have a web app and I will focus on that one.

Each champion pertains to a certain Region in the world and regions also have subregions of their own. With composite
I can display a tree with all the champions and subregions that pertain to a certain region

Advantages:
	allowing the programmer to not rewrite the classes if he wants to add a new type of node
	can easily manage the nodes

Disadvantages:
	programmer must verify at runtime if the node is a leaf or not
