package TicuJianu.Robert.g1100.Builder.Interfaces;

public interface UltimateSkinInterface {
    public void spotlight();
}
